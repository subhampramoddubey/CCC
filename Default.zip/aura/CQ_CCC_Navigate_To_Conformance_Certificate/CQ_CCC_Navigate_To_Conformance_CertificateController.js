({ invoke : function(component, event, helper) {
    var recordId = component.get("v.redirectURL");
    var ourRef = component.get("v.ourRef");
    var custRef = component.get("v.custRef");
    var footerName = component.get("v.footerName");
    var footerDate = component.get("v.footerDate");
    var url = "/apex/CQ_CCC_Insp_CertificateOfConformance?id="+ recordId+"&&ourRef="+ourRef+"&&custRef="+custRef+"&&footerName="+footerName+"&&footerDate="+footerDate;
    console.log(url);
    var redirect = $A.get("e.force:navigateToURL");
    
    
    redirect.setParams({
        "url": url
    });
    
    redirect.fire();
}})