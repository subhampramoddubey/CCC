({ invoke : function(component, event, helper) {
    var record = component.get("v.redirectURL");
    var quantity = component.get("v.quantity");
    var batch = component.get("v.batch");
    var specialNote = component.get("v.specialNote");
    var inspector = component.get("v.inspector");
    var url = "/apex/CQ_CCC_Con_Doc_Generate_Inspection_Label?id="+ record+"&&quantity="+quantity+"&&batch="+batch+"&&specialNote="+specialNote+"&&inspector="+inspector;
    var redirect = $A.get("e.force:navigateToURL");
    
    
    redirect.setParams({
        "url": url
    });
        
   redirect.fire();
}})