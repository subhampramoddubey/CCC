// basic import
import { track, api} from 'lwc';
import cqRecordForm from 'c/cqRecordForm';





// field and schema import

// Object_<Object api name without __c if present>
import OBJECT_COMPLIANCEQUEST__SQX_SPECIFICATION__C from '@salesforce/schema/compliancequest__SQX_Specification__c';

import FIELD_COMPLIANCEQUEST__SQX_SPECIFICATION__C__NAME from '@salesforce/schema/compliancequest__SQX_Specification__c.Name';


// Field_<field api name without __c if present>

import FIELD_COMPLIANCEQUEST__SQX_INSPECTION_CRITERIA__C from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__SQX_Inspection_Criteria__c';

import FIELD_CQ_CCC_INSPECTION_CATEGORY__C from '@salesforce/schema/compliancequest__SQX_Specification__c.CQ_CCC_Inspection_Category__c';

import FIELD_COMPLIANCEQUEST__CHARACTERISTICS__C from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__Characteristics__c';

import FIELD_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__Lower_Spec_Limit__c';

import FIELD_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__Upper_Spec_Limit__c';

import FIELD_CQ_CCC_UNIT_OF_MEASURE__C from '@salesforce/schema/compliancequest__SQX_Specification__c.CQ_CCC_Unit_of_Measure__c';

import FIELD_COMPLIANCEQUEST__IMPACT__C from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__Impact__c';

import FIELD_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__Measurement_Standard__c';

import FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__C from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__SQX_Equipment__c';

import FIELD_COMPLIANCEQUEST__SPECIFICATION__C from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__Specification__c';

import FIELD_COMPLIANCEQUEST__INSPECTION_METHOD__C from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__Inspection_Method__c';

import FIELD_CQ_CCC_SQX_SAMPLING_PLAN_TYPE__C from '@salesforce/schema/compliancequest__SQX_Specification__c.CQ_CCC_SQX_Sampling_Plan_Type__c';

import FIELD_CQ_CCC_AQL__C from '@salesforce/schema/compliancequest__SQX_Specification__c.CQ_CCC_AQL__c';





// additional Field_<field api name without __c if present>



// Lookup fields Field_<field api name without __c if present>_<name field>


    
import FIELD_COMPLIANCEQUEST__SQX_INSPECTION_CRITERIA__NAME from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__SQX_Inspection_Criteria__r.Name';
    


    


    


    


    


    


    


    


    
import FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__NAME from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__SQX_Equipment__r.Name';
    


    


    


    
import FIELD_CQ_CCC_SQX_SAMPLING_PLAN_TYPE__NAME from '@salesforce/schema/compliancequest__SQX_Specification__c.CQ_CCC_SQX_Sampling_Plan_Type__r.Name';
    


    



// import section custom label
    
        
import CQUI_INFORMATION from '@salesforce/label/c.CQ_UI_INFORMATION';
        
    
        
import CQUI_SYSTEM_INFORMATION from '@salesforce/label/c.CQ_UI_SYSTEM_INFORMATION';
        
    
        
import CQUI_CUSTOM_LINKS from '@salesforce/label/c.CQ_UI_CUSTOM_LINKS';
        
    


    


// generated to match the indext with the exact value field


// import as array to help in code generation below

const fields = [
 

    FIELD_COMPLIANCEQUEST__SQX_SPECIFICATION__C__NAME,

    
    FIELD_COMPLIANCEQUEST__SQX_INSPECTION_CRITERIA__C,
    
    FIELD_CQ_CCC_INSPECTION_CATEGORY__C,
    
    FIELD_COMPLIANCEQUEST__CHARACTERISTICS__C,
    
    FIELD_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C,
    
    FIELD_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C,
    
    FIELD_CQ_CCC_UNIT_OF_MEASURE__C,
    
    FIELD_COMPLIANCEQUEST__IMPACT__C,
    
    FIELD_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C,
    
    FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__C,
    
    FIELD_COMPLIANCEQUEST__SPECIFICATION__C,
    
    FIELD_COMPLIANCEQUEST__INSPECTION_METHOD__C,
    
    FIELD_CQ_CCC_SQX_SAMPLING_PLAN_TYPE__C,
    
    FIELD_CQ_CCC_AQL__C,
    
    
    
        
    FIELD_COMPLIANCEQUEST__SQX_INSPECTION_CRITERIA__NAME,
        
    
        
    
        
    
        
    
        
    
        
    
        
    
        
    
        
    FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__NAME,
        
    
        
    
        
    
        
    FIELD_CQ_CCC_SQX_SAMPLING_PLAN_TYPE__NAME,
        
    
        
    
];

const lookupDisplayFields = {
    
    
        
    "compliancequest__SQX_Inspection_Criteria__c": FIELD_COMPLIANCEQUEST__SQX_INSPECTION_CRITERIA__NAME,
    

        

        

        

        

        

        

        

        
    "compliancequest__SQX_Equipment__c": FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__NAME,
    

        

        

        
    "CQ_CCC_SQX_Sampling_Plan_Type__c": FIELD_CQ_CCC_SQX_SAMPLING_PLAN_TYPE__NAME,
    

        

};

const LOOKUP_FILTERS = {};
const DYNAMIC_SOURCES = {};
const FORM_RULES = {"CQ_CCC_SQX_Sampling_Plan_Type__c":{"transfer":[{"fields":["CQ_CCC_SQX_Sampling_Plan_Type__c"],"filter":"record.CQ_CCC_SQX_Sampling_Plan_Type__c   ","action":{"CQ_CCC_AQL__c":["CQ_CCC_AQL__c"]}}],"setValues":[{"fields":["CQ_CCC_SQX_Sampling_Plan_Type__c"],"filter":"!record.CQ_CCC_SQX_Sampling_Plan_Type__c   ","action":{"CQ_CCC_AQL__c":null}}]},"CQ_CCC_AQL__c":{"readonly":{"fields":["CQ_CCC_AQL__c"],"filter":"true"}},"CQ_CCC_Unit_of_Measure__c":{"required":{"fields":["compliancequest__Lower_Spec_Limit__c","compliancequest__Upper_Spec_Limit__c"],"filter":"record.compliancequest__Lower_Spec_Limit__c    || record.compliancequest__Upper_Spec_Limit__c   "}},"onLoad":{"setValues":[{"fields":[""],"filter":"true","action":{"compliancequest__Measurement_Standard__c":"Product Defect"}}]}};
const FORMULA_FIELDS = {};

export default class cquiCCCSpecificationCreate  extends cqRecordForm {
    
    @track
    sectionHider = {};
    fieldsToTrack = [];
    saveImmediate = false;

    constructor() {
        super();
        this.init(OBJECT_COMPLIANCEQUEST__SQX_SPECIFICATION__C,fields,lookupDisplayFields);
        
        
        this.sectionHider = {"expando_unique_id_1":true,"expando_unique_id_2":true,"expando_unique_id_3":true}

        // Extend rules
        this.lookupFilters = LOOKUP_FILTERS;
        this.dynamicSources = DYNAMIC_SOURCES;
        this.inputFormRules = FORM_RULES;
        this.systemFormRules = FORMULA_FIELDS;
        this.picklistValueSource = {
            
        };
        this.uiType = {};
        this.parentRecordApi="";
        
    }


    @api
    get recordId() {
        return this._recordId;
    }
    set recordId(value) {
        this._recordId = value;
        this.parentId = value;
    }

    // getters for field value, display value and field metadata
    
    get v_COMPLIANCEQUEST__SQX_INSPECTION_CRITERIA__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_INSPECTION_CRITERIA__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_INSPECTION_CRITERIA__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_INSPECTION_CRITERIA__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__SQX_INSPECTION_CRITERIA__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_INSPECTION_CRITERIA__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_INSPECTION_CRITERIA__C.fieldApiName].fieldApiName);
    }

    
    get v_CQ_CCC_INSPECTION_CATEGORY__C() {
        return this.getValueFor(FIELD_CQ_CCC_INSPECTION_CATEGORY__C.fieldApiName);
    }
    get f_CQ_CCC_INSPECTION_CATEGORY__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_CQ_CCC_INSPECTION_CATEGORY__C.fieldApiName] : {};
        return val;
    }

    get d_CQ_CCC_INSPECTION_CATEGORY__C() {
        return lookupDisplayFields[FIELD_CQ_CCC_INSPECTION_CATEGORY__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_CQ_CCC_INSPECTION_CATEGORY__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__CHARACTERISTICS__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__CHARACTERISTICS__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__CHARACTERISTICS__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__CHARACTERISTICS__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__CHARACTERISTICS__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__CHARACTERISTICS__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__CHARACTERISTICS__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C.fieldApiName].fieldApiName);
    }

    
    get v_CQ_CCC_UNIT_OF_MEASURE__C() {
        return this.getValueFor(FIELD_CQ_CCC_UNIT_OF_MEASURE__C.fieldApiName);
    }
    get f_CQ_CCC_UNIT_OF_MEASURE__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_CQ_CCC_UNIT_OF_MEASURE__C.fieldApiName] : {};
        return val;
    }

    get d_CQ_CCC_UNIT_OF_MEASURE__C() {
        return lookupDisplayFields[FIELD_CQ_CCC_UNIT_OF_MEASURE__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_CQ_CCC_UNIT_OF_MEASURE__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__IMPACT__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__IMPACT__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__IMPACT__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__IMPACT__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__IMPACT__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__IMPACT__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__IMPACT__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SQX_EQUIPMENT__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_EQUIPMENT__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__SQX_EQUIPMENT__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SPECIFICATION__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SPECIFICATION__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SPECIFICATION__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SPECIFICATION__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__SPECIFICATION__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SPECIFICATION__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SPECIFICATION__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__INSPECTION_METHOD__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__INSPECTION_METHOD__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__INSPECTION_METHOD__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__INSPECTION_METHOD__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__INSPECTION_METHOD__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__INSPECTION_METHOD__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__INSPECTION_METHOD__C.fieldApiName].fieldApiName);
    }

    
    get v_CQ_CCC_SQX_SAMPLING_PLAN_TYPE__C() {
        return this.getValueFor(FIELD_CQ_CCC_SQX_SAMPLING_PLAN_TYPE__C.fieldApiName);
    }
    get f_CQ_CCC_SQX_SAMPLING_PLAN_TYPE__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_CQ_CCC_SQX_SAMPLING_PLAN_TYPE__C.fieldApiName] : {};
        return val;
    }

    get d_CQ_CCC_SQX_SAMPLING_PLAN_TYPE__C() {
        return lookupDisplayFields[FIELD_CQ_CCC_SQX_SAMPLING_PLAN_TYPE__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_CQ_CCC_SQX_SAMPLING_PLAN_TYPE__C.fieldApiName].fieldApiName);
    }

    
    get v_CQ_CCC_AQL__C() {
        return this.getValueFor(FIELD_CQ_CCC_AQL__C.fieldApiName);
    }
    get f_CQ_CCC_AQL__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_CQ_CCC_AQL__C.fieldApiName] : {};
        return val;
    }

    get d_CQ_CCC_AQL__C() {
        return lookupDisplayFields[FIELD_CQ_CCC_AQL__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_CQ_CCC_AQL__C.fieldApiName].fieldApiName);
    }

    


    
        
    get CQUIINFORMATION() {
        return CQUI_INFORMATION;
    }
        
    
        
    get CQUISYSTEM_INFORMATION() {
        return CQUI_SYSTEM_INFORMATION;
    }
        
    
        
    get CQUICUSTOM_LINKS() {
        return CQUI_CUSTOM_LINKS;
    }
        
    
}