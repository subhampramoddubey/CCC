// basic import
import { wire,track, api} from 'lwc';
import cqRecordForm from 'c/cqRecordForm';
import { addDays }  from 'c/cqBase';





// field and schema import

// Object_<Object api name without __c if present>
import OBJECT_COMPLIANCEQUEST__SQX_INVESTIGATION__C from '@salesforce/schema/compliancequest__SQX_Investigation__c';

import FIELD_COMPLIANCEQUEST__SQX_INVESTIGATION__C__NAME from '@salesforce/schema/compliancequest__SQX_Investigation__c.Name';


    import FIELD_RECORDTYPENAME from '@salesforce/schema/compliancequest__SQX_Investigation__c.RecordType.Name';
    import FIELD_RECORDTYPEDEVELOPERNAME from '@salesforce/schema/compliancequest__SQX_Investigation__c.RecordType.DeveloperName';


// Field_<field api name without __c if present>

import FIELD_RECORDTYPEID from '@salesforce/schema/compliancequest__SQX_Investigation__c.RecordTypeId';

import FIELD_COMPLIANCEQUEST__TYPE_OF_INVESTIGATION__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__Type_of_Investigation__c';

import FIELD_COMPLIANCEQUEST__SQX_CAPA__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_CAPA__c';

import FIELD_COMPLIANCEQUEST__SQX_COMPLAINT__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Complaint__c';

import FIELD_COMPLIANCEQUEST__SQX_FINDING__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Finding__c';

import FIELD_COMPLIANCEQUEST__SQX_NONCONFORMANCE__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Nonconformance__c';

import FIELD_COMPLIANCEQUEST__SQX_PART_FAMILY__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Part_Family__c';

import FIELD_COMPLIANCEQUEST__STATUS__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__Status__c';

import FIELD_COMPLIANCEQUEST__SQX_PART__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Part__c';

import FIELD_COMPLIANCEQUEST__SQX_ACCOUNT__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Account__c';

import FIELD_COMPLIANCEQUEST__LOT_NUMBER__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__Lot_Number__c';

import FIELD_COMPLIANCEQUEST__REVISION__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__Revision__c';

import FIELD_COMPLIANCEQUEST__SQX_DEFECT_CODE__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Defect_Code__c';

import FIELD_COMPLIANCEQUEST__QN_5W1H_WHAT__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__QN_5W1H_What__c';

import FIELD_COMPLIANCEQUEST__QN_5W1H_WHEN__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__QN_5W1H_When__c';

import FIELD_COMPLIANCEQUEST__QN_5W1H_WHERE__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__QN_5W1H_Where__c';

import FIELD_COMPLIANCEQUEST__QN_5W1H_WHICH__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__QN_5W1H_Which__c';

import FIELD_COMPLIANCEQUEST__QN_5W1H_WHO__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__QN_5W1H_Who__c';

import FIELD_COMPLIANCEQUEST__QN_5W1H_HOW__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__QN_5W1H_How__c';

import FIELD_COMPLIANCEQUEST__QN_5W2H_HOW_MANY__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__QN_5W2H_How_Many__c';

import FIELD_COMPLIANCEQUEST__INVESTIGATION_SUMMARY__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__Investigation_Summary__c';

import FIELD_COMPLIANCEQUEST__SQX_ORIGINAL_INVESTIGATION__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Original_Investigation__c';

import FIELD_COMPLIANCEQUEST__CONCLUSION__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__Conclusion__c';

import FIELD_COMPLIANCEQUEST__SQX_PRIMARY_DIAGNOSTIC__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Primary_Diagnostic__c';

import FIELD_COMPLIANCEQUEST__SQX_SECONDARY_DIAGNOSTIC__C from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Secondary_Diagnostic__c';





// additional Field_<field api name without __c if present>



// Lookup fields Field_<field api name without __c if present>_<name field>


    


    


    
import FIELD_COMPLIANCEQUEST__SQX_CAPA__NAME from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_CAPA__r.Name';
    


    
import FIELD_COMPLIANCEQUEST__SQX_COMPLAINT__NAME from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Complaint__r.Name';
    


    
import FIELD_COMPLIANCEQUEST__SQX_FINDING__NAME from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Finding__r.Name';
    


    
import FIELD_COMPLIANCEQUEST__SQX_NONCONFORMANCE__NAME from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Nonconformance__r.Name';
    


    
import FIELD_COMPLIANCEQUEST__SQX_PART_FAMILY__NAME from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Part_Family__r.Name';
    


    


    
import FIELD_COMPLIANCEQUEST__SQX_PART__NAME from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Part__r.Name';
    


    
import FIELD_COMPLIANCEQUEST__SQX_ACCOUNT__NAME from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Account__r.Name';
    


    


    


    
import FIELD_COMPLIANCEQUEST__SQX_DEFECT_CODE__NAME from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Defect_Code__r.Name';
    


    


    


    


    


    


    


    


    


    
import FIELD_COMPLIANCEQUEST__SQX_ORIGINAL_INVESTIGATION__NAME from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Original_Investigation__r.Name';
    


    


    
import FIELD_COMPLIANCEQUEST__SQX_PRIMARY_DIAGNOSTIC__NAME from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Primary_Diagnostic__r.Name';
    


    
import FIELD_COMPLIANCEQUEST__SQX_SECONDARY_DIAGNOSTIC__NAME from '@salesforce/schema/compliancequest__SQX_Investigation__c.compliancequest__SQX_Secondary_Diagnostic__r.Name';
    



// import section custom label
    
        
import CQUI_INVESTIGATION_TYPE from '@salesforce/label/cqext.CQUI_INVESTIGATION_TYPE';
        
    
        
import CQUI_SOURCE_CAPA from '@salesforce/label/cqext.CQUI_SOURCE_CAPA';
        
    
        
import CQUI_SOURCE_COMPLAINT from '@salesforce/label/cqext.CQUI_SOURCE_COMPLAINT';
        
    
        
import CQUI_SOURCE_FINDING from '@salesforce/label/cqext.CQUI_SOURCE_FINDING';
        
    
        
import CQUI_SOURCE_NC from '@salesforce/label/cqext.CQUI_SOURCE_NC';
        
    
        
import CQUI_INFORMATION from '@salesforce/label/cqext.CQUI_INFORMATION';
        
    
        
import CQUI_5W2H_PROBLEM_SOLVING from '@salesforce/label/cqext.CQUI_5W2H_PROBLEM_SOLVING';
        
    
        
import CQUI_DETAIL from '@salesforce/label/cqext.CQUI_DETAIL';
        
    
        
import CQUI_CONCLUSION from '@salesforce/label/cqext.CQUI_CONCLUSION';
        
    
        
import CQUI_CUSTOM_LINKS from '@salesforce/label/cqext.CQUI_CUSTOM_LINKS';
        
    


// generated to match the indext with the exact value field


// import as array to help in code generation below

const fields = [

    FIELD_RECORDTYPENAME,
    FIELD_RECORDTYPEDEVELOPERNAME,
  

    FIELD_COMPLIANCEQUEST__SQX_INVESTIGATION__C__NAME,

    
    FIELD_RECORDTYPEID,
    
    FIELD_COMPLIANCEQUEST__TYPE_OF_INVESTIGATION__C,
    
    FIELD_COMPLIANCEQUEST__SQX_CAPA__C,
    
    FIELD_COMPLIANCEQUEST__SQX_COMPLAINT__C,
    
    FIELD_COMPLIANCEQUEST__SQX_FINDING__C,
    
    FIELD_COMPLIANCEQUEST__SQX_NONCONFORMANCE__C,
    
    FIELD_COMPLIANCEQUEST__SQX_PART_FAMILY__C,
    
    FIELD_COMPLIANCEQUEST__STATUS__C,
    
    FIELD_COMPLIANCEQUEST__SQX_PART__C,
    
    FIELD_COMPLIANCEQUEST__SQX_ACCOUNT__C,
    
    FIELD_COMPLIANCEQUEST__LOT_NUMBER__C,
    
    FIELD_COMPLIANCEQUEST__REVISION__C,
    
    FIELD_COMPLIANCEQUEST__SQX_DEFECT_CODE__C,
    
    FIELD_COMPLIANCEQUEST__QN_5W1H_WHAT__C,
    
    FIELD_COMPLIANCEQUEST__QN_5W1H_WHEN__C,
    
    FIELD_COMPLIANCEQUEST__QN_5W1H_WHERE__C,
    
    FIELD_COMPLIANCEQUEST__QN_5W1H_WHICH__C,
    
    FIELD_COMPLIANCEQUEST__QN_5W1H_WHO__C,
    
    FIELD_COMPLIANCEQUEST__QN_5W1H_HOW__C,
    
    FIELD_COMPLIANCEQUEST__QN_5W2H_HOW_MANY__C,
    
    FIELD_COMPLIANCEQUEST__INVESTIGATION_SUMMARY__C,
    
    FIELD_COMPLIANCEQUEST__SQX_ORIGINAL_INVESTIGATION__C,
    
    FIELD_COMPLIANCEQUEST__CONCLUSION__C,
    
    FIELD_COMPLIANCEQUEST__SQX_PRIMARY_DIAGNOSTIC__C,
    
    FIELD_COMPLIANCEQUEST__SQX_SECONDARY_DIAGNOSTIC__C,
    
    
    
        
    
        
    
        
            FIELD_COMPLIANCEQUEST__SQX_CAPA__NAME,
        
    
        
            FIELD_COMPLIANCEQUEST__SQX_COMPLAINT__NAME,
        
    
        
            FIELD_COMPLIANCEQUEST__SQX_FINDING__NAME,
        
    
        
            FIELD_COMPLIANCEQUEST__SQX_NONCONFORMANCE__NAME,
        
    
        
            FIELD_COMPLIANCEQUEST__SQX_PART_FAMILY__NAME,
        
    
        
    
        
            FIELD_COMPLIANCEQUEST__SQX_PART__NAME,
        
    
        
            FIELD_COMPLIANCEQUEST__SQX_ACCOUNT__NAME,
        
    
        
    
        
    
        
            FIELD_COMPLIANCEQUEST__SQX_DEFECT_CODE__NAME,
        
    
        
    
        
    
        
    
        
    
        
    
        
    
        
    
        
    
        
            FIELD_COMPLIANCEQUEST__SQX_ORIGINAL_INVESTIGATION__NAME,
        
    
        
    
        
            FIELD_COMPLIANCEQUEST__SQX_PRIMARY_DIAGNOSTIC__NAME,
        
    
        
            FIELD_COMPLIANCEQUEST__SQX_SECONDARY_DIAGNOSTIC__NAME,
        
    
];

const lookupDisplayFields = {
    
        "RecordTypeId": FIELD_RECORDTYPENAME,
    
    
        

        

        
            "compliancequest__SQX_CAPA__c": FIELD_COMPLIANCEQUEST__SQX_CAPA__NAME,
    

        
            "compliancequest__SQX_Complaint__c": FIELD_COMPLIANCEQUEST__SQX_COMPLAINT__NAME,
    

        
            "compliancequest__SQX_Finding__c": FIELD_COMPLIANCEQUEST__SQX_FINDING__NAME,
    

        
            "compliancequest__SQX_Nonconformance__c": FIELD_COMPLIANCEQUEST__SQX_NONCONFORMANCE__NAME,
    

        
            "compliancequest__SQX_Part_Family__c": FIELD_COMPLIANCEQUEST__SQX_PART_FAMILY__NAME,
    

        

        
            "compliancequest__SQX_Part__c": FIELD_COMPLIANCEQUEST__SQX_PART__NAME,
    

        
            "compliancequest__SQX_Account__c": FIELD_COMPLIANCEQUEST__SQX_ACCOUNT__NAME,
    

        

        

        
            "compliancequest__SQX_Defect_Code__c": FIELD_COMPLIANCEQUEST__SQX_DEFECT_CODE__NAME,
    

        

        

        

        

        

        

        

        

        
            "compliancequest__SQX_Original_Investigation__c": FIELD_COMPLIANCEQUEST__SQX_ORIGINAL_INVESTIGATION__NAME,
    

        

        
            "compliancequest__SQX_Primary_Diagnostic__c": FIELD_COMPLIANCEQUEST__SQX_PRIMARY_DIAGNOSTIC__NAME,
    

        
            "compliancequest__SQX_Secondary_Diagnostic__c": FIELD_COMPLIANCEQUEST__SQX_SECONDARY_DIAGNOSTIC__NAME,
    

};

const LOOKUP_FILTERS = {"compliancequest__SQX_Associated_Item__c":{"filters":[{"field":"compliancequest__SQX_Complaint__c","operator":"eq","dynamicValue":"compliancequest__SQX_Complaint__c","isDynamic":true}],"logic":"and"},"compliancequest__SQX_CAPA__c":{"filters":[{"field":"compliancequest__Status__c","operator":"neq","value":"Closed"},{"field":"compliancequest__Status__c","operator":"neq","value":"Void"},{"field":"compliancequest__Status__c","operator":"neq","value":"Complete"}],"logic":"and"},"compliancequest__SQX_Complaint__c":{"filters":[{"field":"compliancequest__Status__c","operator":"neq","value":"Closed"},{"field":"compliancequest__Status__c","operator":"neq","value":"Void"}],"logic":"and"},"compliancequest__SQX_Defect_Code__c":{"filters":[{"field":"compliancequest__Active__c","operator":"eq","value":"True"},{"field":"compliancequest__Type__c","operator":"eq","value":"Complaint Code"}],"logic":"and"},"compliancequest__SQX_Finding__c":{"filters":[{"field":"compliancequest__Status__c","operator":"neq","value":"Closed"},{"field":"compliancequest__Status__c","operator":"neq","value":"Complete"}],"logic":"and"},"compliancequest__SQX_Nonconformance__c":{"filters":[{"field":"compliancequest__Status__c","operator":"neq","value":"Closed"},{"field":"compliancequest__Status__c","operator":"neq","value":"Void"},{"field":"compliancequest__Status__c","operator":"neq","value":"Complete"}],"logic":"and"},"compliancequest__SQX_Part__c":{"filters":[{"field":"compliancequest__Active__c","operator":"eq","value":"True"}],"logic":"and"},"compliancequest__SQX_Primary_Diagnostic__c":{"filters":[{"field":"compliancequest__Type__c","operator":"eq","value":"Complaint Conclusion"},{"field":"compliancequest__Active__c","operator":"eq","value":"True"}],"logic":"and"},"compliancequest__SQX_Secondary_Diagnostic__c":{"filters":[{"field":"compliancequest__Type__c","operator":"eq","value":"Complaint Conclusion"},{"field":"compliancequest__Active__c","operator":"eq","value":"True"}],"logic":"and"}};
const DYNAMIC_SOURCES = {};
const FORM_RULES = {
    "RecordTypeId":{
       "readonly":{
          "fields":[
             "RecordTypeId"
          ],
          "filter":"true"
       }
    },
    "compliancequest__SQX_CAPA__c":{
       "hidden":{
          "fields":[
             "compliancequest__SQX_CAPA__c"
          ],
          "filter":"true"
       }
    },
    "compliancequest__SQX_Complaint__c":{
       "hidden":{
          "fields":[
             "compliancequest__SQX_Complaint__c"
          ],
          "filter":"true"
       }
    },
    "compliancequest__SQX_Defect_Code__c":{
        "hidden":{
           "fields":[
              "compliancequest__SQX_Defect_Code__c"
           ],
           "filter":"true"
        }
     },
    "compliancequest__SQX_Finding__c":{
       "hidden":{
          "fields":[
             "compliancequest__SQX_Finding__c"
          ],
          "filter":"true"
       }
    },
    "compliancequest__SQX_Nonconformance__c":{
       "readonly":{
          "fields":[
             "compliancequest__SQX_Nonconformance__c"
          ],
          "filter":"true"
       }
    },
    "compliancequest__SQX_Original_Investigation__c":{
       "hidden":{
          "fields":[
             "compliancequest__SQX_Original_Investigation__c"
          ],
          "filter":"true"
       }
    },
    "compliancequest__SQX_Primary_Diagnostic__c":{
       "hidden":{
          "fields":[
             "compliancequest__SQX_Primary_Diagnostic__c"
          ],
          "filter":"true"
       }
    },
    "compliancequest__SQX_Secondary_Diagnostic__c":{
       "hidden":{
          "fields":[
             "compliancequest__SQX_Secondary_Diagnostic__c"
          ],
          "filter":"true"
       }
    },
    "compliancequest__Revision__c":{
       "hidden":{
          "fields":[
             "compliancequest__Revision__c"
          ],
          "filter":"true"
       }
    },
    "onInit":{
       "invoke":{
          "fields":[
            "compliancequest__Nonconformance__c"
          ],
          "action":[
             {
                "name":"CQUI_NC_Set_NC_Investigation_Record_Type",
                "ns":"cqext"
             }
          ]
       }
    }
 };
const FORMULA_FIELDS = {};

export default class cqui_Nonconformance_createinvestigation  extends cqRecordForm {
    
    @track
    sectionHider = {};
    fieldsToTrack = [];
    saveImmediate = false;

    constructor() {
        super();
        this.init(OBJECT_COMPLIANCEQUEST__SQX_INVESTIGATION__C,fields,lookupDisplayFields);
        
        this.sectionHider = {"expando_unique_id_1":true,"expando_unique_id_2":true,"expando_unique_id_3":true,"expando_unique_id_4":true,"expando_unique_id_5":true,"expando_unique_id_6":true,"expando_unique_id_7":true,"expando_unique_id_8":true,"expando_unique_id_9":true,"expando_unique_id_10":true}

        // Extend rules
        this.lookupFilters = LOOKUP_FILTERS;
        this.dynamicSources = DYNAMIC_SOURCES;
        this.inputFormRules = FORM_RULES;
        this.systemFormRules = FORMULA_FIELDS;
        this.picklistValueSource = {
            
        };
        this.uiType = {};
    }


    @api
    get recordId() {
        return this._recordId;
    }
    set recordId(value) {
        this._recordId = value;
        this.parentId = value;
    }

    // getters for field value, display value and field metadata
    
    get v_RECORDTYPEID() {
        return this.getValueFor(FIELD_RECORDTYPEID.fieldApiName);
    }
    get f_RECORDTYPEID() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_RECORDTYPEID.fieldApiName] : {};
         return val;
    }

    get d_RECORDTYPEID() {
        return lookupDisplayFields[FIELD_RECORDTYPEID.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_RECORDTYPEID.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__TYPE_OF_INVESTIGATION__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__TYPE_OF_INVESTIGATION__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__TYPE_OF_INVESTIGATION__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__TYPE_OF_INVESTIGATION__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__TYPE_OF_INVESTIGATION__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__TYPE_OF_INVESTIGATION__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__TYPE_OF_INVESTIGATION__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SQX_CAPA__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_CAPA__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_CAPA__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_CAPA__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__SQX_CAPA__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_CAPA__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_CAPA__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SQX_COMPLAINT__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_COMPLAINT__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_COMPLAINT__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_COMPLAINT__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__SQX_COMPLAINT__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_COMPLAINT__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_COMPLAINT__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SQX_FINDING__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_FINDING__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_FINDING__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_FINDING__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__SQX_FINDING__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_FINDING__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_FINDING__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SQX_NONCONFORMANCE__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_NONCONFORMANCE__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_NONCONFORMANCE__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_NONCONFORMANCE__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__SQX_NONCONFORMANCE__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_NONCONFORMANCE__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_NONCONFORMANCE__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SQX_PART_FAMILY__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_PART_FAMILY__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_PART_FAMILY__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_PART_FAMILY__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__SQX_PART_FAMILY__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_PART_FAMILY__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_PART_FAMILY__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__STATUS__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__STATUS__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__STATUS__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__STATUS__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__STATUS__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__STATUS__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__STATUS__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SQX_PART__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_PART__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_PART__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_PART__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__SQX_PART__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_PART__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_PART__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SQX_ACCOUNT__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_ACCOUNT__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_ACCOUNT__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_ACCOUNT__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__SQX_ACCOUNT__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_ACCOUNT__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_ACCOUNT__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__LOT_NUMBER__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__LOT_NUMBER__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__LOT_NUMBER__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__LOT_NUMBER__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__LOT_NUMBER__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__LOT_NUMBER__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__LOT_NUMBER__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__REVISION__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__REVISION__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__REVISION__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__REVISION__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__REVISION__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__REVISION__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__REVISION__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SQX_DEFECT_CODE__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_DEFECT_CODE__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_DEFECT_CODE__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_DEFECT_CODE__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__SQX_DEFECT_CODE__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_DEFECT_CODE__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_DEFECT_CODE__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__QN_5W1H_WHAT__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__QN_5W1H_WHAT__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__QN_5W1H_WHAT__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__QN_5W1H_WHAT__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__QN_5W1H_WHAT__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__QN_5W1H_WHAT__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__QN_5W1H_WHAT__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__QN_5W1H_WHEN__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__QN_5W1H_WHEN__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__QN_5W1H_WHEN__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__QN_5W1H_WHEN__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__QN_5W1H_WHEN__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__QN_5W1H_WHEN__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__QN_5W1H_WHEN__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__QN_5W1H_WHERE__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__QN_5W1H_WHERE__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__QN_5W1H_WHERE__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__QN_5W1H_WHERE__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__QN_5W1H_WHERE__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__QN_5W1H_WHERE__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__QN_5W1H_WHERE__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__QN_5W1H_WHICH__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__QN_5W1H_WHICH__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__QN_5W1H_WHICH__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__QN_5W1H_WHICH__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__QN_5W1H_WHICH__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__QN_5W1H_WHICH__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__QN_5W1H_WHICH__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__QN_5W1H_WHO__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__QN_5W1H_WHO__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__QN_5W1H_WHO__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__QN_5W1H_WHO__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__QN_5W1H_WHO__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__QN_5W1H_WHO__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__QN_5W1H_WHO__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__QN_5W1H_HOW__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__QN_5W1H_HOW__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__QN_5W1H_HOW__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__QN_5W1H_HOW__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__QN_5W1H_HOW__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__QN_5W1H_HOW__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__QN_5W1H_HOW__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__QN_5W2H_HOW_MANY__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__QN_5W2H_HOW_MANY__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__QN_5W2H_HOW_MANY__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__QN_5W2H_HOW_MANY__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__QN_5W2H_HOW_MANY__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__QN_5W2H_HOW_MANY__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__QN_5W2H_HOW_MANY__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__INVESTIGATION_SUMMARY__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__INVESTIGATION_SUMMARY__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__INVESTIGATION_SUMMARY__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__INVESTIGATION_SUMMARY__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__INVESTIGATION_SUMMARY__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__INVESTIGATION_SUMMARY__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__INVESTIGATION_SUMMARY__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SQX_ORIGINAL_INVESTIGATION__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_ORIGINAL_INVESTIGATION__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_ORIGINAL_INVESTIGATION__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_ORIGINAL_INVESTIGATION__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__SQX_ORIGINAL_INVESTIGATION__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_ORIGINAL_INVESTIGATION__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_ORIGINAL_INVESTIGATION__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__CONCLUSION__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__CONCLUSION__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__CONCLUSION__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__CONCLUSION__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__CONCLUSION__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__CONCLUSION__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__CONCLUSION__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SQX_PRIMARY_DIAGNOSTIC__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_PRIMARY_DIAGNOSTIC__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_PRIMARY_DIAGNOSTIC__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_PRIMARY_DIAGNOSTIC__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__SQX_PRIMARY_DIAGNOSTIC__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_PRIMARY_DIAGNOSTIC__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_PRIMARY_DIAGNOSTIC__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SQX_SECONDARY_DIAGNOSTIC__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_SECONDARY_DIAGNOSTIC__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_SECONDARY_DIAGNOSTIC__C() {
         let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_SECONDARY_DIAGNOSTIC__C.fieldApiName] : {};
         return val;
    }

    get d_COMPLIANCEQUEST__SQX_SECONDARY_DIAGNOSTIC__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_SECONDARY_DIAGNOSTIC__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_SECONDARY_DIAGNOSTIC__C.fieldApiName].fieldApiName);
    }

    


    
        
    get CQUIINVESTIGATION_TYPE() {
        return CQUI_INVESTIGATION_TYPE;
    }
        
    
        
    get CQUISOURCE_CAPA() {
        return CQUI_SOURCE_CAPA;
    }
        
    
        
    get CQUISOURCE_COMPLAINT() {
        return CQUI_SOURCE_COMPLAINT;
    }
        
    
        
    get CQUISOURCE_FINDING() {
        return CQUI_SOURCE_FINDING;
    }
        
    
        
    get CQUISOURCE_NC() {
        return CQUI_SOURCE_NC;
    }
        
    
        
    get CQUIINFORMATION() {
        return CQUI_INFORMATION;
    }
        
    
        
    get CQUI5W2H_PROBLEM_SOLVING() {
        return CQUI_5W2H_PROBLEM_SOLVING;
    }
        
    
        
    get CQUIDETAIL() {
        return CQUI_DETAIL;
    }
        
    
        
    get CQUICONCLUSION() {
        return CQUI_CONCLUSION;
    }
        
    
        
    get CQUICUSTOM_LINKS() {
        return CQUI_CUSTOM_LINKS;
    }
        
    
}