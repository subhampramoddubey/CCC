import {api } from 'lwc';
import CqGridForm from 'c/cqGridForm';
import COMPLIANCEQUEST__SQX_SPECIFICATION__C from '@salesforce/schema/compliancequest__SQX_Specification__c';


import FIELDS_PARENT_ID from '@salesforce/schema/compliancequest__SQX_Controlled_Document__c.Id';

import FIELDS_PARENT_NAME from '@salesforce/schema/compliancequest__SQX_Controlled_Document__c.Name';





//import fields


import FIELDS_COMPLIANCEQUEST__SQX_SPECIFICATION__C_CQ_CCC_INSPECTION_CATEGORY__C from '@salesforce/schema/compliancequest__SQX_Specification__c.CQ_CCC_Inspection_Category__c';

import FIELDS_COMPLIANCEQUEST__SQX_SPECIFICATION__C_COMPLIANCEQUEST__CHARACTERISTICS__C from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__Characteristics__c';

import FIELDS_COMPLIANCEQUEST__SQX_SPECIFICATION__C_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__Lower_Spec_Limit__c';

import FIELDS_COMPLIANCEQUEST__SQX_SPECIFICATION__C_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__Upper_Spec_Limit__c';

import FIELDS_COMPLIANCEQUEST__SQX_SPECIFICATION__C_CQ_CCC_UNIT_OF_MEASURE__C from '@salesforce/schema/compliancequest__SQX_Specification__c.CQ_CCC_Unit_of_Measure__c';

import FIELDS_COMPLIANCEQUEST__SQX_SPECIFICATION__C_COMPLIANCEQUEST__IMPACT__C from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__Impact__c';

import FIELDS_COMPLIANCEQUEST__SQX_SPECIFICATION__C_COMPLIANCEQUEST__SQX_INSPECTION_CRITERIA__C from '@salesforce/schema/compliancequest__SQX_Specification__c.compliancequest__SQX_Inspection_Criteria__c';


//import customlabels (Labels must not have space)

import CQUI_NEW from '@salesforce/label/c.CQ_UI_NEW';





//additonalFields added in query while fetching data
const additionalFields = [



];
const columns = [


    FIELDS_COMPLIANCEQUEST__SQX_SPECIFICATION__C_CQ_CCC_INSPECTION_CATEGORY__C,

        
    FIELDS_COMPLIANCEQUEST__SQX_SPECIFICATION__C_COMPLIANCEQUEST__CHARACTERISTICS__C,

        
    FIELDS_COMPLIANCEQUEST__SQX_SPECIFICATION__C_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C,

        
    FIELDS_COMPLIANCEQUEST__SQX_SPECIFICATION__C_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C,

        
    FIELDS_COMPLIANCEQUEST__SQX_SPECIFICATION__C_CQ_CCC_UNIT_OF_MEASURE__C,

        
    FIELDS_COMPLIANCEQUEST__SQX_SPECIFICATION__C_COMPLIANCEQUEST__IMPACT__C,

        
    
];

const parentFields = [

    FIELDS_PARENT_ID,

    FIELDS_PARENT_NAME,

];

export default class cquiCCCSpecificationGrid  extends CqGridForm {
    @api
    maxRows;

    @api
    maxColumns;

    @api
    gridType;

    @api
    flexipageRegionWidth;
    
    constructor() {
        super();
        this.fields = columns;
        this.columns = columns;
        this.mainObject = COMPLIANCEQUEST__SQX_SPECIFICATION__C;
        this.relationalField = FIELDS_COMPLIANCEQUEST__SQX_SPECIFICATION__C_COMPLIANCEQUEST__SQX_INSPECTION_CRITERIA__C; //todo use this in import
        this.additionalFields = additionalFields;
        this.parentFields = parentFields;

        
        this.headerActions = [{"label": CQUI_NEW,"name":"std_new","componentName":"cqui-ccc-specification-create"},];
        

        this.limitToRecordType = '';

        
        this.rowActions = [];
        

        
        this.rowFormRules = {};
        

        
        this.headerFormRules = {};
        

        
        this.iconName = 'standard:contract_line_item';
        
        
    
        

        

        

        

        

        this.componentName="cquiCCCSpecificationGrid";

    }

    connectedCallback(){
        this.maxRowsToDisplay = this.maxRows;
        this.maxColumnsToDisplay = this.maxColumns;
        this.gridDesktopView = this.gridType;
    }

    @api 
    get recordId() {
        return this._recordId;
    }

    set recordId(value) {
        this._recordId = value;
    }

}