// basic import
import { track, api} from 'lwc';
import cqRecordForm from 'c/cqRecordForm';





// field and schema import

// Object_<Object api name without __c if present>
import OBJECT_COMPLIANCEQUEST__SQX_INSPECTION_DETAIL__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c';


// Field_<field api name without __c if present>

import FIELD_NAME from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.Name';

import FIELD_COMPLIANCEQUEST__EQUIPMENT_CALIBRATED__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Equipment_Calibrated__c';

import FIELD_COMPLIANCEQUEST__SQX_INSPECTION__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__SQX_Inspection__c';

import FIELD_CQ_CCC_INSPECTION_CATEGORY__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.CQ_CCC_Inspection_Category__c';

import FIELD_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Lower_Spec_Limit__c';

import FIELD_CQ_CCC_CRITICAL_CHARACTERISTIC__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.CQ_CCC_Critical_Characteristic__c';

import FIELD_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Upper_Spec_Limit__c';

import FIELD_CQ_CCC_UNIT_OF_MEASURE__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.CQ_CCC_Unit_of_Measure__c';

import FIELD_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Measurement_Standard__c';

import FIELD_COMPLIANCEQUEST__CHARACTERISTICS__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Characteristics__c';

import FIELD_COMPLIANCEQUEST__SPECIFICATION__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Specification__c';

import FIELD_COMPLIANCEQUEST__INSPECTION_METHOD__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Inspection_Method__c';

import FIELD_COMPLIANCEQUEST__OBSERVATION__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Observation__c';

import FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__SQX_Equipment__c';

import FIELD_COMPLIANCEQUEST__OBSERVED_VALUE__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Observed_Value__c';

import FIELD_COMPLIANCEQUEST__SAMPLE_SIZE__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Sample_Size__c';

import FIELD_COMPLIANCEQUEST__RESULT__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Result__c';

import FIELD_COMPLIANCEQUEST__NUMBER_OF_DEFECTS__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Number_of_Defects__c';

import FIELD_COMPLIANCEQUEST__NEED_FOLLOWUP__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Need_Followup__c';

import FIELD_COMPLIANCEQUEST__DEFECTIVE_QUANTITY__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Defective_Quantity__c';

import FIELD_COMPLIANCEQUEST__IMMEDIATE_ACTION__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Immediate_Action__c';

import FIELD_COMPLIANCEQUEST__COMMENT__C from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__Comment__c';

import FIELD_CREATEDBYID from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.CreatedById';

import FIELD_LASTMODIFIEDBYID from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.LastModifiedById';





// additional Field_<field api name without __c if present>



// Lookup fields Field_<field api name without __c if present>_<name field>


    


    


    
import FIELD_COMPLIANCEQUEST__SQX_INSPECTION__NAME from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__SQX_Inspection__r.Name';
    


    


    


    


    


    


    


    


    


    
import FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__NAME from '@salesforce/schema/compliancequest__SQX_Inspection_Detail__c.compliancequest__SQX_Equipment__r.Name';
    


    


    


    


    


    


    


    


    


    


    
// import section custom label
    
        
import CQUI_INFORMATION from '@salesforce/label/c.CQ_UI_INFORMATION';
        
        
        
import CQUI_INSPECTION from '@salesforce/label/c.CQ_UI_INSPECTION';
        
    
        
import CQUI_COMMENT from '@salesforce/label/c.CQ_UI_COMMENT';
        
    
        
import CQUI_SYSTEM_INFORMATION from '@salesforce/label/c.CQ_UI_SYSTEM_INFORMATION';
        
    
        
import CQUI_CUSTOM_LINKS from '@salesforce/label/c.CQ_UI_CUSTOM_LINKS';
        
    


    


// generated to match the indext with the exact value field


// import as array to help in code generation below

const fields = [
 

    
    FIELD_NAME,
    
    FIELD_COMPLIANCEQUEST__EQUIPMENT_CALIBRATED__C,
    
    FIELD_COMPLIANCEQUEST__SQX_INSPECTION__C,
    
    FIELD_CQ_CCC_INSPECTION_CATEGORY__C,
    
    FIELD_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C,
    
    FIELD_CQ_CCC_CRITICAL_CHARACTERISTIC__C,
    
    FIELD_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C,
    
    FIELD_CQ_CCC_UNIT_OF_MEASURE__C,
    
    FIELD_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C,
    
    FIELD_COMPLIANCEQUEST__CHARACTERISTICS__C,
    
    FIELD_COMPLIANCEQUEST__SPECIFICATION__C,
    
    FIELD_COMPLIANCEQUEST__INSPECTION_METHOD__C,
    
    FIELD_COMPLIANCEQUEST__OBSERVATION__C,
    
    FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__C,
    
    FIELD_COMPLIANCEQUEST__OBSERVED_VALUE__C,
    
    FIELD_COMPLIANCEQUEST__SAMPLE_SIZE__C,
    
    FIELD_COMPLIANCEQUEST__RESULT__C,
    
    FIELD_COMPLIANCEQUEST__NUMBER_OF_DEFECTS__C,
    
    FIELD_COMPLIANCEQUEST__NEED_FOLLOWUP__C,
    
    FIELD_COMPLIANCEQUEST__DEFECTIVE_QUANTITY__C,
    
    FIELD_COMPLIANCEQUEST__IMMEDIATE_ACTION__C,
    
    FIELD_COMPLIANCEQUEST__COMMENT__C,
    
    FIELD_CREATEDBYID,
    
    FIELD_LASTMODIFIEDBYID,
    
    
    
        
    
        
    
        
    FIELD_COMPLIANCEQUEST__SQX_INSPECTION__NAME,
        
    
        
    
        
    
        
    
        
    
        
    
        
    
        
    
        
    
        
    FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__NAME,
        
    
        
    
        
    
        
    
        
    
        
    
        
    
        
    
        
    
        
    
];

const lookupDisplayFields = {
    
    
        

        

        
    "compliancequest__SQX_Inspection__c": FIELD_COMPLIANCEQUEST__SQX_INSPECTION__NAME,
    

        

        

        

        

        

        

        

        

        
    "compliancequest__SQX_Equipment__c": FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__NAME,
    

        

        

        

        

        

        

        

        

        

};

const LOOKUP_FILTERS = {};
const DYNAMIC_SOURCES = {};
const FORM_RULES = {};
const FORMULA_FIELDS = {};

export default class cquiCCCInspectionDetailBoth  extends cqRecordForm {
    
    @track
    sectionHider = {};
    fieldsToTrack = [];
    saveImmediate = false;

    constructor() {
        super();
        this.init(OBJECT_COMPLIANCEQUEST__SQX_INSPECTION_DETAIL__C,fields,lookupDisplayFields);
        
        
        this.sectionHider = {"expando_unique_id_1":true,"expando_unique_id_2":true,"expando_unique_id_3":true,"expando_unique_id_4":true,"expando_unique_id_5":true,"expando_unique_id_6":true}

        // Extend rules
        this.lookupFilters = LOOKUP_FILTERS;
        this.dynamicSources = DYNAMIC_SOURCES;
        this.inputFormRules = FORM_RULES;
        this.systemFormRules = FORMULA_FIELDS;
        this.picklistValueSource = {
            
        };
        this.uiType = {};
        this.parentRecordApi="";
        
    }


    @api
    get recordId() {
        return this._recordId;
    }
    set recordId(value) {
        this._recordId = value;
        this.parentId = value;
    }

    // getters for field value, display value and field metadata
    
    get v_NAME() {
        return this.getValueFor(FIELD_NAME.fieldApiName);
    }
    get f_NAME() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_NAME.fieldApiName] : {};
        return val;
    }

    get d_NAME() {
        return lookupDisplayFields[FIELD_NAME.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_NAME.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__EQUIPMENT_CALIBRATED__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__EQUIPMENT_CALIBRATED__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__EQUIPMENT_CALIBRATED__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__EQUIPMENT_CALIBRATED__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__EQUIPMENT_CALIBRATED__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__EQUIPMENT_CALIBRATED__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__EQUIPMENT_CALIBRATED__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SQX_INSPECTION__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_INSPECTION__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_INSPECTION__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_INSPECTION__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__SQX_INSPECTION__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_INSPECTION__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_INSPECTION__C.fieldApiName].fieldApiName);
    }

    
    get v_CQ_CCC_INSPECTION_CATEGORY__C() {
        return this.getValueFor(FIELD_CQ_CCC_INSPECTION_CATEGORY__C.fieldApiName);
    }
    get f_CQ_CCC_INSPECTION_CATEGORY__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_CQ_CCC_INSPECTION_CATEGORY__C.fieldApiName] : {};
        return val;
    }

    get d_CQ_CCC_INSPECTION_CATEGORY__C() {
        return lookupDisplayFields[FIELD_CQ_CCC_INSPECTION_CATEGORY__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_CQ_CCC_INSPECTION_CATEGORY__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__LOWER_SPEC_LIMIT__C.fieldApiName].fieldApiName);
    }

    
    get v_CQ_CCC_CRITICAL_CHARACTERISTIC__C() {
        return this.getValueFor(FIELD_CQ_CCC_CRITICAL_CHARACTERISTIC__C.fieldApiName);
    }
    get f_CQ_CCC_CRITICAL_CHARACTERISTIC__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_CQ_CCC_CRITICAL_CHARACTERISTIC__C.fieldApiName] : {};
        return val;
    }

    get d_CQ_CCC_CRITICAL_CHARACTERISTIC__C() {
        return lookupDisplayFields[FIELD_CQ_CCC_CRITICAL_CHARACTERISTIC__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_CQ_CCC_CRITICAL_CHARACTERISTIC__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__UPPER_SPEC_LIMIT__C.fieldApiName].fieldApiName);
    }

    
    get v_CQ_CCC_UNIT_OF_MEASURE__C() {
        return this.getValueFor(FIELD_CQ_CCC_UNIT_OF_MEASURE__C.fieldApiName);
    }
    get f_CQ_CCC_UNIT_OF_MEASURE__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_CQ_CCC_UNIT_OF_MEASURE__C.fieldApiName] : {};
        return val;
    }

    get d_CQ_CCC_UNIT_OF_MEASURE__C() {
        return lookupDisplayFields[FIELD_CQ_CCC_UNIT_OF_MEASURE__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_CQ_CCC_UNIT_OF_MEASURE__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__MEASUREMENT_STANDARD__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__CHARACTERISTICS__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__CHARACTERISTICS__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__CHARACTERISTICS__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__CHARACTERISTICS__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__CHARACTERISTICS__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__CHARACTERISTICS__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__CHARACTERISTICS__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SPECIFICATION__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SPECIFICATION__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SPECIFICATION__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SPECIFICATION__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__SPECIFICATION__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SPECIFICATION__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SPECIFICATION__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__INSPECTION_METHOD__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__INSPECTION_METHOD__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__INSPECTION_METHOD__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__INSPECTION_METHOD__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__INSPECTION_METHOD__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__INSPECTION_METHOD__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__INSPECTION_METHOD__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__OBSERVATION__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__OBSERVATION__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__OBSERVATION__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__OBSERVATION__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__OBSERVATION__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__OBSERVATION__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__OBSERVATION__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SQX_EQUIPMENT__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SQX_EQUIPMENT__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__SQX_EQUIPMENT__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SQX_EQUIPMENT__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__OBSERVED_VALUE__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__OBSERVED_VALUE__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__OBSERVED_VALUE__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__OBSERVED_VALUE__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__OBSERVED_VALUE__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__OBSERVED_VALUE__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__OBSERVED_VALUE__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__SAMPLE_SIZE__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__SAMPLE_SIZE__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__SAMPLE_SIZE__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__SAMPLE_SIZE__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__SAMPLE_SIZE__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__SAMPLE_SIZE__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__SAMPLE_SIZE__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__RESULT__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__RESULT__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__RESULT__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__RESULT__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__RESULT__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__RESULT__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__RESULT__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__NUMBER_OF_DEFECTS__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__NUMBER_OF_DEFECTS__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__NUMBER_OF_DEFECTS__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__NUMBER_OF_DEFECTS__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__NUMBER_OF_DEFECTS__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__NUMBER_OF_DEFECTS__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__NUMBER_OF_DEFECTS__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__NEED_FOLLOWUP__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__NEED_FOLLOWUP__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__NEED_FOLLOWUP__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__NEED_FOLLOWUP__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__NEED_FOLLOWUP__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__NEED_FOLLOWUP__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__NEED_FOLLOWUP__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__DEFECTIVE_QUANTITY__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__DEFECTIVE_QUANTITY__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__DEFECTIVE_QUANTITY__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__DEFECTIVE_QUANTITY__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__DEFECTIVE_QUANTITY__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__DEFECTIVE_QUANTITY__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__DEFECTIVE_QUANTITY__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__IMMEDIATE_ACTION__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__IMMEDIATE_ACTION__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__IMMEDIATE_ACTION__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__IMMEDIATE_ACTION__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__IMMEDIATE_ACTION__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__IMMEDIATE_ACTION__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__IMMEDIATE_ACTION__C.fieldApiName].fieldApiName);
    }

    
    get v_COMPLIANCEQUEST__COMMENT__C() {
        return this.getValueFor(FIELD_COMPLIANCEQUEST__COMMENT__C.fieldApiName);
    }
    get f_COMPLIANCEQUEST__COMMENT__C() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_COMPLIANCEQUEST__COMMENT__C.fieldApiName] : {};
        return val;
    }

    get d_COMPLIANCEQUEST__COMMENT__C() {
        return lookupDisplayFields[FIELD_COMPLIANCEQUEST__COMMENT__C.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_COMPLIANCEQUEST__COMMENT__C.fieldApiName].fieldApiName);
    }

    
    get v_CREATEDBYID() {
        return this.getValueFor(FIELD_CREATEDBYID.fieldApiName);
    }
    get f_CREATEDBYID() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_CREATEDBYID.fieldApiName] : {};
        return val;
    }

    get d_CREATEDBYID() {
        return lookupDisplayFields[FIELD_CREATEDBYID.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_CREATEDBYID.fieldApiName].fieldApiName);
    }

    
    get v_LASTMODIFIEDBYID() {
        return this.getValueFor(FIELD_LASTMODIFIEDBYID.fieldApiName);
    }
    get f_LASTMODIFIEDBYID() {
        let val=this.fieldsInfo ? this.fieldsInfo[FIELD_LASTMODIFIEDBYID.fieldApiName] : {};
        return val;
    }

    get d_LASTMODIFIEDBYID() {
        return lookupDisplayFields[FIELD_LASTMODIFIEDBYID.fieldApiName] && this.getValueFor(lookupDisplayFields[FIELD_LASTMODIFIEDBYID.fieldApiName].fieldApiName);
    }

    


    
        
    get CQUIINFORMATION() {
        return CQUI_INFORMATION;
    }
        
    
        
    get CQUIINSPECTION() {
        return CQUI_INSPECTION;
    }
        
    
        
    get CQUICOMMENT() {
        return CQUI_COMMENT;
    }
        
    
        
    get CQUISYSTEM_INFORMATION() {
        return CQUI_SYSTEM_INFORMATION;
    }
        
    
        
    get CQUICUSTOM_LINKS() {
        return CQUI_CUSTOM_LINKS;
    }
        
    
}